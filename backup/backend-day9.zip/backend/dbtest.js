const connection = mysql.createConnection({
  host: '172.31.90.85',
  port: 3306,
  user: 'vamsi',         // ✅ New DB user
  password: 'Vamsi321',
  database: 'user_info',
  connectTimeout: 10000
});

